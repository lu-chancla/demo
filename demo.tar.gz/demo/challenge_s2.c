#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct UserData {
    int authenticated;       // Should remain 0
    char username[16];       // Attacker can overflow this
    int privilege_level;     // Should remain 1
};

void check_status(struct UserData *u) {
    printf("\n=== User Status ===\n");
    printf("Authenticated: %d\n", u->authenticated);
    printf("Username: %s\n", u->username);
    printf("Privilege Level: %d\n", u->privilege_level);
}

void vulnerable() {
    struct UserData user;

    // Initialize fields
    user.authenticated = 0;
    strcpy(user.username, "guest");
    user.privilege_level = 1;

    char input[64];

    printf("Enter your username: ");
    gets(input);   // ❗ Vulnerable: allows overflow into struct fields

    // Unsafe copy: no bounds checking
    //strcpy(user.username, input);
    memcpy(user.username, input, sizeof(input));

    check_status(&user);

    if (user.privilege_level == 12) {
        system("pwd");
        if (!strcmp(user.username, "admin")) {
            system("ls -l");
        }
    }
}

int main() {
    printf("Struct-overwrite practice program.\n");
    vulnerable();
    return 0;
}

