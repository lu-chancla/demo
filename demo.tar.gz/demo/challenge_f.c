#include <stdio.h>
#include <string.h>

void greet(char* user_input) {

    char name[128];

    // Copying user input into a buffer
    strcpy(name, user_input);
    name[127] = '\0';

    // Insecure use of printf()
    // The user_input is used directly as the format string.
    printf(name);
    printf("\n");
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <name>\n", argv[0]);
        return 1;
    }
    greet(argv[1]);
    return 0;
}
