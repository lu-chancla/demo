# ToC
1. challenge_f
2. challenge_o
3. challenge_s1
4. challenge_s2


## challenge_f

- Trigger a bug.

## challenge_o

- Find a bug
- Use it to execute the code in the secret function.

## challenge_s1

- Can you change your information somehow?

## challenge_s2

- There is some weird logic here...
- Can I bypass checks to enter new branches?