#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// gcc -fno-stack-protector -z execstack -o vuln vuln.c
// gcc -m32 -fno-stack-protector -z execstack -no-pie -o vuln vuln.c

void secret_function() {
    printf("You reached secret_function()! Overflow successful.\n");
}

void vulnerable() {
    char buffer[32];

    printf("Enter some text: ");
    gets(buffer);  // ! Vulnerable: gets() does not check length, can overwrite the stack

    printf("You entered: %s\n", buffer);
}

int main() {
    printf("Simple RE practice program.\n");
    vulnerable();
    printf("Exiting program.\n");
    return 0;
}
