#!/bin/bash

apt install gcc make gdb checksec -y